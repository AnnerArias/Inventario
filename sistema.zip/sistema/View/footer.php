</div>
</div>
<script>
    $(document).ready(function() {
        $('#tabla').DataTable({
            "language": {
                "url": "assets/es/es-ES.json"
            }
        });
    });
</script>
<script src="assets/js/scripts.js"></script>
<script src="cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
</body>

</html>